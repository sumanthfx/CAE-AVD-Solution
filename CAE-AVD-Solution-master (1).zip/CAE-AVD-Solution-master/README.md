# FX-CAE-AVD-Solution
AVD Solution

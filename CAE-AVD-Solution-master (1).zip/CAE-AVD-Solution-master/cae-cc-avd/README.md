## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>2.99.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 2.99.0 |
| <a name="provider_random"></a> [random](#provider\_random) | 3.1.3 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_network_interface.avd_vm_nic_de](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface) | resource |
| [azurerm_network_interface.avd_vm_nic_ds](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface) | resource |
| [azurerm_resource_group.rg_cace_sessionhost](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.rg_personal_cace](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_virtual_desktop_application_group.dag_personal_cace_datascience](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_desktop_application_group) | resource |
| [azurerm_virtual_desktop_application_group.dag_personal_cace_de](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_desktop_application_group) | resource |
| [azurerm_virtual_desktop_host_pool.hostpool_personal_cace_de](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_desktop_host_pool) | resource |
| [azurerm_virtual_desktop_host_pool.hostpool_personal_cace_ds](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_desktop_host_pool) | resource |
| [azurerm_virtual_desktop_host_pool_registration_info.de](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_desktop_host_pool_registration_info) | resource |
| [azurerm_virtual_desktop_host_pool_registration_info.ds](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_desktop_host_pool_registration_info) | resource |
| [azurerm_virtual_desktop_workspace.workspace_personal_cace_de](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_desktop_workspace) | resource |
| [azurerm_virtual_desktop_workspace.workspace_personal_cace_ds](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_desktop_workspace) | resource |
| [azurerm_virtual_desktop_workspace_application_group_association.ws-dag_cace_personal_de](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_desktop_workspace_application_group_association) | resource |
| [azurerm_virtual_desktop_workspace_application_group_association.ws-dag_cace_personal_ds](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_desktop_workspace_application_group_association) | resource |
| [azurerm_virtual_machine_extension.domain_join_de](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_extension) | resource |
| [azurerm_virtual_machine_extension.domain_join_ds](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_extension) | resource |
| [azurerm_virtual_machine_extension.vmext_dec_de](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_extension) | resource |
| [azurerm_virtual_machine_extension.vmext_dsc_ds](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_extension) | resource |
| [azurerm_windows_virtual_machine.avd_vm_de](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/windows_virtual_machine) | resource |
| [azurerm_windows_virtual_machine.avd_vm_ds](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/windows_virtual_machine) | resource |
| [random_string.AVD_local_password_de](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/string) | resource |
| [random_string.AVD_local_password_ds](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/string) | resource |
| [azurerm_subnet.avd_personal_cace_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subnet) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_de_prefix"></a> [de\_prefix](#input\_de\_prefix) | Prefix of the name of the AVD machine(s) | `string` | `"vmcacpeng"` | no |
| <a name="input_domain_name"></a> [domain\_name](#input\_domain\_name) | Name of the domain to join | `string` | `"aadcae.com"` | no |
| <a name="input_domain_password"></a> [domain\_password](#input\_domain\_password) | Password of the user to authenticate with the domain | `string` | n/a | yes |
| <a name="input_domain_user_upn"></a> [domain\_user\_upn](#input\_domain\_user\_upn) | Username for domain join (do not include domain name as this is appended) | `string` | `"svc_azurevdi_jad"` | no |
| <a name="input_ds_prefix"></a> [ds\_prefix](#input\_ds\_prefix) | Prefix of the name of the AVD machine(s) | `string` | `"vmcacpsct"` | no |
| <a name="input_hostpool_personal_cace_dataengineer"></a> [hostpool\_personal\_cace\_dataengineer](#input\_hostpool\_personal\_cace\_dataengineer) | Name of the Azure Virtual Desktop host pool | `string` | `"cae-it-cace-hostpool-p-avdDataEngineer"` | no |
| <a name="input_hostpool_personal_cace_datascience"></a> [hostpool\_personal\_cace\_datascience](#input\_hostpool\_personal\_cace\_datascience) | Name of the Azure Virtual Desktop host pool | `string` | `"cae-it-cace-hostpool-p-avdDataScience"` | no |
| <a name="input_local_admin_password"></a> [local\_admin\_password](#input\_local\_admin\_password) | local admin password | `any` | n/a | yes |
| <a name="input_local_admin_username"></a> [local\_admin\_username](#input\_local\_admin\_username) | local admin username | `string` | `"caeadmin"` | no |
| <a name="input_location"></a> [location](#input\_location) | Location of resources | `string` | `"canadacentral"` | no |
| <a name="input_rdsh_count_de"></a> [rdsh\_count\_de](#input\_rdsh\_count\_de) | Number of AVD machines to deploy for data engineers | `number` | `1` | no |
| <a name="input_rdsh_count_ds"></a> [rdsh\_count\_ds](#input\_rdsh\_count\_ds) | Number of AVD machines to deploy for data science | `number` | `1` | no |
| <a name="input_rg_name_cace_sessionhosts_personal"></a> [rg\_name\_cace\_sessionhosts\_personal](#input\_rg\_name\_cace\_sessionhosts\_personal) | Name of the Resource group in which to deploy AVD objects resources | `string` | `"cae-it-cace-rg-p-avdpersonalhosts001"` | no |
| <a name="input_rg_name_personal_cace"></a> [rg\_name\_personal\_cace](#input\_rg\_name\_personal\_cace) | Resource group for canada central hostpool | `string` | `"cae-it-cace-rg-p-avdpersonal001"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags to apply on resource groups | `map(string)` | <pre>{<br>  "CostCenter": "",<br>  "Department": "IT",<br>  "Description": "AVD Virtual Desktop Resources",<br>  "Environment": "PROD",<br>  "OrgUnit": "",<br>  "Owner": "",<br>  "ProjectName": "AVD"<br>}</pre> | no |
| <a name="input_vm_size"></a> [vm\_size](#input\_vm\_size) | Size of the machine to deploy | `string` | `"Standard_DS4_v2"` | no |
| <a name="input_workspace_personal_cace_dataengineer"></a> [workspace\_personal\_cace\_dataengineer](#input\_workspace\_personal\_cace\_dataengineer) | Name of the Azure Virtual Desktop workspace | `string` | `"cae-it-cace-avd-workspace-personal-DataEngineer"` | no |
| <a name="input_workspace_personal_cace_datascience"></a> [workspace\_personal\_cace\_datascience](#input\_workspace\_personal\_cace\_datascience) | Name of the Azure Virtual Desktop workspace | `string` | `"cae-it-cace-avd-workspace-personal-DataScience"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_subnet_id_cace_staging"></a> [subnet\_id\_cace\_staging](#output\_subnet\_id\_cace\_staging) | n/a |
